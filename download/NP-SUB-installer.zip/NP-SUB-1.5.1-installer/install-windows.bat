@echo off
chcp 65001 >nul
setlocal enableextensions

rem ============================================================
rem   NP SUB — установщик панели для Adobe Premiere Pro (Windows)
rem   Двойной клик. Права администратора НЕ нужны.
rem   Ставит панель в папку расширений пользователя и включает
rem   режим самоподписанных расширений (PlayerDebugMode) для
rem   всех версий Premiere (CEP 9–13).
rem ============================================================

set "SRC=%~dp0NP-SUB"
if defined KZSUB_CEP_EXTENSIONS_DIR (
  set "EXTENSIONS_DIR=%KZSUB_CEP_EXTENSIONS_DIR%"
) else (
  set "EXTENSIONS_DIR=%APPDATA%\Adobe\CEP\extensions"
)
set "DEST=%EXTENSIONS_DIR%\kz.kzsub.panel"
set "BACKUP=%EXTENSIONS_DIR%\kz.kzsub.panel.backup"

echo.
echo ==== Установка панели NP SUB ====
echo.

if not exist "%SRC%\CSXS\manifest.xml" (
  echo ОШИБКА: рядом с этим файлом нет папки NP-SUB с плагином.
  echo Распакуйте архив ПОЛНОСТЬЮ и запустите установщик из распакованной папки.
  echo.
  pause
  exit /b 1
)

echo [1/4] Проверяю файлы и включаю режим расширений...
if not "%KZSUB_SKIP_DEBUG_MODE%"=="1" (
  for %%V in (9 10 11 12 13) do (
    reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
  )
)

echo [2/4] Сохраняю предыдущую установку...
if not exist "%EXTENSIONS_DIR%" mkdir "%EXTENSIONS_DIR%" >nul 2>&1
if exist "%BACKUP%" rmdir /S /Q "%BACKUP%"
if exist "%DEST%" move /Y "%DEST%" "%BACKUP%" >nul

echo [3/4] Копирую и проверяю панель...
xcopy "%SRC%" "%DEST%\" /E /I /Y /Q >nul
if errorlevel 1 (
  goto :rollback
)
if not exist "%DEST%\CSXS\manifest.xml" goto :rollback
if not exist "%DEST%\index.html" goto :rollback
if exist "%BACKUP%" rmdir /S /Q "%BACKUP%"

echo [4/4] Готово!
echo.
echo Панель установлена сюда:
echo   %DEST%
echo.
echo Дальше:
echo   1. Полностью закройте и снова откройте Premiere Pro.
echo   2. Верхнее меню: Window - Extensions - NP SUB.
echo   3. Введите ключ активации.
echo.
if not defined KZSUB_NONINTERACTIVE pause
endlocal
exit /b 0

:rollback
echo.
echo ОШИБКА: установка не завершена. Восстанавливаю предыдущую версию.
if exist "%DEST%" rmdir /S /Q "%DEST%"
if exist "%BACKUP%" move /Y "%BACKUP%" "%DEST%" >nul
echo Закройте Premiere Pro и попробуйте ещё раз.
echo.
if not defined KZSUB_NONINTERACTIVE pause
endlocal
exit /b 1
