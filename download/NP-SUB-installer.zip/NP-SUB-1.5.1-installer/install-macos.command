#!/bin/bash
# ============================================================
#   NP SUB — установщик панели для Adobe Premiere Pro (macOS)
#   Двойной клик в Finder. Пароль/root НЕ нужны — всё ставится
#   в домашнюю папку пользователя.
#   Ставит панель в папку расширений и включает режим
#   самоподписанных расширений (PlayerDebugMode) для всех
#   версий Premiere (CEP 9–13).
# ============================================================

# Папка, где лежит сам установщик (рядом должна быть папка NP-SUB).
DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$DIR/NP-SUB"
EXTENSIONS_DIR="${KZSUB_CEP_EXTENSIONS_DIR:-$HOME/Library/Application Support/Adobe/CEP/extensions}"
DEST="$EXTENSIONS_DIR/kz.kzsub.panel"
BACKUP="$EXTENSIONS_DIR/kz.kzsub.panel.backup"

echo ""
echo "==== Установка панели NP SUB ===="
echo ""

if [ ! -f "$SRC/CSXS/manifest.xml" ]; then
  echo "ОШИБКА: рядом с установщиком нет папки NP-SUB с плагином."
  echo "Распакуйте архив полностью и запустите установщик из распакованной папки."
  echo ""
  read -r -p "Нажмите Enter, чтобы закрыть..." _
  exit 1
fi

echo "[1/4] Проверяю файлы и включаю режим расширений..."
if [ "${KZSUB_SKIP_DEBUG_MODE:-0}" != "1" ]; then
  for v in 9 10 11 12 13; do
    defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1 >/dev/null 2>&1 || true
  done
  # macOS кэширует plist; после перезапуска процесса новые значения применятся.
  killall cfprefsd >/dev/null 2>&1 || true
fi

echo "[2/4] Сохраняю предыдущую установку..."
mkdir -p "$EXTENSIONS_DIR"
rm -rf "$BACKUP"
if [ -e "$DEST" ] || [ -L "$DEST" ]; then
  mv "$DEST" "$BACKUP"
fi

rollback() {
  trap - ERR INT TERM
  echo "ОШИБКА: установка не завершена. Восстанавливаю предыдущую версию."
  rm -rf "$DEST"
  if [ -e "$BACKUP" ] || [ -L "$BACKUP" ]; then
    mv "$BACKUP" "$DEST"
  fi
  exit 1
}
trap rollback ERR INT TERM

echo "[3/4] Копирую и проверяю панель..."
cp -R "$SRC" "$DEST"
# Снимаем «карантин» с скопированных файлов (иначе macOS может блокировать).
xattr -dr com.apple.quarantine "$DEST" >/dev/null 2>&1 || true

if [ ! -f "$DEST/CSXS/manifest.xml" ] || [ ! -f "$DEST/index.html" ]; then
  false
fi

rm -rf "$BACKUP"
trap - ERR INT TERM

echo "[4/4] Готово!"
echo ""
echo "Панель установлена сюда:"
echo "  $DEST"
echo ""
echo "Дальше:"
echo "  1. Полностью закройте и снова откройте Premiere Pro."
echo "  2. Верхнее меню: Window → Extensions → NP SUB."
echo "  3. Введите ключ активации."
echo ""
if [ "${KZSUB_NONINTERACTIVE:-0}" != "1" ]; then
  read -r -p "Нажмите Enter, чтобы закрыть..." _
fi
